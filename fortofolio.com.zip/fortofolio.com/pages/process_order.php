<?php
// Sertakan file koneksi database
include 'includes/koneksi.php';

// Cek apakah formulir telah dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Simpan data dari formulir ke dalam variabel
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $service = $_POST['service'];
    $quantity = $_POST['quantity'] ? $_POST['quantity'] : NULL; // NULL jika kosong
    $message = $_POST['message'];

    // Dapatkan ID layanan berdasarkan nama layanan
    $stmt = $conn->prepare("SELECT id FROM layanan WHERE nama LIKE ?");
    $stmt->bind_param("s", $service);
    $stmt->execute();
    $result = $stmt->get_result();
    $service_id = ($result->num_rows > 0) ? $result->fetch_assoc()['id'] : NULL;
    
    $stmt->close();

    // Siapkan perintah SQL untuk memasukkan data ke tabel orders
    $sql = "INSERT INTO orders (name, email, phone, service_id, quantity, message) VALUES (?, ?, ?, ?, ?, ?)";

    // Gunakan prepared statement untuk menghindari SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssiss", $name, $email, $phone, $service_id, $quantity, $message);

    // Eksekusi perintah SQL dan cek apakah berhasil
    if ($stmt->execute()) {
        echo "<script>alert('Pesanan berhasil dikirim!'); window.location.href='contact.php#contact';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Tutup statement dan koneksi
    $stmt->close();
    $conn->close();
}
?>
