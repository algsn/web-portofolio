<section id="portfolio">
    <h1 class="header">Tentang Saya</h1>
    <?php
        $nama = "Muhammad Al Gisna Syuban";
        $pendidikan = "Lulusan SLTA, saat ini mahasiswa Teknik Informatika di Universitas Pembangunan Jaya";
        $bidangKeahlian = "Jaringan, Otomotif, dan Service Laptop/PC";
        $visi = "Menjadi seorang profesional yang mampu memberikan solusi teknologi berkelanjutan dan inovatif, terutama di bidang jaringan komputer dan perangkat elektronik, serta berkontribusi dalam perkembangan teknologi yang bermanfaat bagi masyarakat luas.";
        $misi = [
            "Mengembangkan kemampuan dalam jaringan komputer dan otomotif melalui pendidikan formal dan pengalaman praktis.",
            "Meningkatkan pengetahuan di bidang teknologi terbaru dan aplikasinya dalam kehidupan sehari-hari, terutama yang mendukung efisiensi dan produktivitas.",
            "Memberikan layanan teknis yang andal dan profesional dalam perbaikan serta pemeliharaan perangkat elektronik dan komputer.",
            "Membangun jejaring dengan para profesional dan komunitas dalam bidang teknologi untuk bertukar pengetahuan serta mengembangkan keterampilan secara berkelanjutan."
        ];
        $pengalaman = [
            "Teknisi komputer di sekolah dasar selama 6 bulan.",
            "Membantu dalam pengaturan jaringan komputer untuk UMKM.",
            "Freelance dalam servis dan perbaikan laptop/PC selama 3 tahun."
        ];
        $proyekTerbaru = [
            "Membangun sistem hotspot lokal di sekolah setempat.",
            "Melakukan perbaikan dan optimasi komputer di sekolah dasar dan sekolah menengah pertama.",
            "Menyiapkan VLAN untuk bisnis lokal yang membutuhkan solusi jaringan terisolasi."
        ];
        $portofolio = [
            "Implementasi jaringan VLAN dan hotspot untuk sekolah.",
            "Perbaikan dan optimasi sistem komputer untuk kantor lokal."
        ];
    ?>
    <div class="deskripsi">
        <h1>Nama saya <strong><?php echo $nama; ?></strong>. Saya memiliki pendidikan terakhir di tingkat SLTA dan saat ini sedang menempuh studi di jurusan Teknik Informatika di Universitas Pembangunan Jaya.</h1>
        <p>Saya memiliki keahlian di bidang <strong><?php echo $bidangKeahlian; ?></strong>, termasuk pembuatan jaringan VLAN, hotspot, dan koneksi peer-to-peer, serta kemampuan untuk melakukan servis dan perbaikan komputer atau laptop. Selain itu, saya juga memiliki keterampilan di bidang otomotif, khususnya untuk kendaraan roda dua.</p>
    </div>
    <div class="visi-misi">
        <div class="visi">
            <h2>Visi</h2>
            <p><?php echo $visi; ?></p>
        </div>
        <div class="misi">
            <h3>Misi</h3>
            <ul>
                <?php foreach ($misi as $point) : ?>
                    <li><?php echo $point; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="container-proyek">
        <div class="pengalaman">
            <h1>Pengalaman</h1>
            <ul>
                <?php foreach ($pengalaman as $exp) : ?>
                    <li><?php echo $exp; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="proyek">           
            <h1>Proyek Terbaru</h1>
            <ul>
                <?php foreach ($proyekTerbaru as $proyek) : ?>
                    <li><?php echo $proyek; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

    <h1>Sertifikat</h1>
    <p>Anda dapat melihat sertifikat yang saya peroleh melalui <a href="https://drive.google.com/drive/folders/1q17FKt_9SDqRNEd2ZZiY7KMbAablplUW?usp=sharing" target="_blank">link Google Drive ini</a>.</p>
</section>

</html>
