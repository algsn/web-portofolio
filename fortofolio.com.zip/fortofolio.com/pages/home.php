<section id="home">
    <div class="container-home">
        <div class="detail">
            <h1 >Selamat Datang </h1> 
            <h1 style="color:orangered;"> di Portofolio Saya </h1>
            <p>Halo! Saya Muhammad Al Gisna Syuban, seorang ahli dalam jaringan, servis komputer, dan otomotif. Selamat datang di portofolio profesional saya.</p>
        </div>
        <div class="foto">        
             <img src="images/profil.jpg" alt="Muhammad Al Gisna Syuban" style="width:250px;height:300px;">         
        </div>
    </div>
</section>
