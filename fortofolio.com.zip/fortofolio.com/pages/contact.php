<!-- Section Contact -->
<?php
// Sertakan file koneksi database
include 'includes/koneksi.php';

// Ambil data profil dari database
$sql = "SELECT nama, alamat, bidang_keahlian AS deskripsi, email, jenis_kelamin, no_telepon, link_gmaps FROM profil WHERE id = 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Menampilkan data profil
    $row = $result->fetch_assoc();
    $nama = $row['nama'];
    $alamat = $row['alamat'];
    $deskripsi = $row['deskripsi'];
    $email = $row['email'];
    $jenis_kelamin = $row['jenis_kelamin'];
    $no_telepon = $row['no_telepon'];
    $link_gmaps = $row['link_gmaps'];
} else {
    echo "Data profil tidak ditemukan.";
}

// Tutup koneksi database
$conn->close();
?> 

<section id="contact">
    <div class="kontak">
        <h2>Kontak</h2>
        <p><strong>No. Telepon:</strong> <?php echo htmlspecialchars($no_telepon); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
        <p><strong>Alamat:</strong> <?php echo htmlspecialchars($alamat); ?></p>
    </div>
    
    <!-- Google Maps Embed -->
    <div class="map" >
        <iframe 
            width="100%" 
            height="300" 
            frameborder="0" 
            style="border:0" 
            src="https://maps.google.com/maps?q=<?php echo urlencode($alamat); ?>&output=embed" 
            allowfullscreen>
        </iframe>
        <p><a href="<?php echo htmlspecialchars($link_gmaps); ?>" target="_blank">Lihat di Google Maps</a></p>
    </div>

    <!-- Tautan langsung ke peta yang disediakan -->
    
</section>