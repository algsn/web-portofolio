<?php
// Sertakan file koneksi database
include 'includes/koneksi.php';

// Ambil data profil dari database
$sql = "SELECT nama, alamat, bidang_keahlian AS deskripsi, email, jenis_kelamin, no_telepon, link_gmaps FROM profil WHERE id = 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Menampilkan data profil
    $row = $result->fetch_assoc();
    $nama = $row['nama'];
    $alamat = $row['alamat'];
    $deskripsi = $row['deskripsi'];
    $email = $row['email'];
    $jenis_kelamin = $row['jenis_kelamin'];
    $no_telepon = $row['no_telepon'];
    $link_gmaps = $row['link_gmaps'];
} else {
    echo "Data profil tidak ditemukan.";
}

// Tutup koneksi database
$conn->close();
?>

<!-- Section About -->
<section id="about">
    <h2>Tentang Saya</h2>
    <p><strong>Nama:</strong> <?php echo htmlspecialchars($nama); ?></p>
    <p><strong>Jenis Kelamin:</strong> <?php echo htmlspecialchars($jenis_kelamin); ?></p>
    <p><strong>Alamat:</strong> <?php echo htmlspecialchars($alamat); ?></p>
    <p><strong>Deskripsi:</strong> <?php echo htmlspecialchars($deskripsi); ?></p>
</section>


