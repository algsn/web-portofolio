<section id="services">
    <h2 class="header-service">Layanan Saya</h2>
    <div class="service-container">
        <div class="service-box">
            <img src="images/mikrotik.jpg" alt="Mikrotik Icon" class="service-icon">
            <h3>Mikrotik</h3>
            <p>Konfigurasi dan pengaturan perangkat jaringan Mikrotik untuk kebutuhan bisnis atau pribadi.</p>
        </div>
        <div class="service-box">
            <img src="images/laptop.png" alt="Laptop/PC Service Icon" class="service-icon">
            <h3>Servis Laptop/PC</h3>
            <p>Perbaikan, pemeliharaan, dan peningkatan performa untuk perangkat laptop atau komputer.</p>
        </div>
        <div class="service-box">
            <img src="images/montir.png" alt="Otomotif Icon" class="service-icon">
            <h3>Otomotif Kendaraan Roda Dua</h3>
            <p>Servis dan perbaikan kendaraan roda dua untuk memastikan performa yang optimal.</p>
        </div>
        <div class="service-box">
            <img src="images/cisco.png" alt="Cisco Icon" class="service-icon">
            <h3>Cisco</h3>
            <p>Instalasi dan konfigurasi perangkat Cisco untuk jaringan yang handal dan aman.</p>
        </div>
    </div>
</section>
