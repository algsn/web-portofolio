<?php
    include 'includes/header.php';
?>

<div class="content-wrapper">
    <?php
        if (isset($_GET['page'])) {
            $page = $_GET['page'];
            switch ($page) {
                case 'portfolio':
                    include 'pages/portfolio.php';
                    break;
                case 'services':
                    include 'pages/services.php';
                    break;
                case 'about':
                    include 'pages/about.php';
                    break;
                case 'contact':
                    include 'pages/contact.php';
                    break;
                default:
                    include 'pages/home.php';
            }
        } else {
            include 'pages/home.php';
        }
    ?>
</div>

<?php
    include 'includes/footer.php';
?>
