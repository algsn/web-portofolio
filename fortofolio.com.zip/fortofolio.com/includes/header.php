<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portofolio Muhammad Al Gisna Syuban</title>
    <link rel="stylesheet" href="css/style.css">
    <! -- font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo+Black&family=DynaPuff:wght@400..700&family=Merriweather+Sans:ital,wght@0,300..800;1,300..800&family=Permanent+Marker&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="logo">
            <span>Portofolio Muhammad</span>
            <span style="color:orangered;">Al Gisna Syuban</span> 
        </div>
        <nav>
            <ul>
                <li><a href="index.php?page=home">Home</a></li>
                <li><a href="index.php?page=portfolio">Portofolio</a></li>
                <li><a href="index.php?page=services">Layanan</a></li>
                <li><a href="index.php?page=about">Tentang</a></li>
                <li><a href="index.php?page=contact">Kontak</a></li>
            </ul>
        </nav>
    </header>
