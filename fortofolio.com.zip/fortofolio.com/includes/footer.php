<footer>
    <p>&copy; 2024 Muhammad Al Gisna Syuban. Semua hak dilindungi.</p>
</footer>
